let pets = [];
let permissoesPorPerfil = {};
let moduloAtivo = "Dashboard";

// DICIONÁRIO DE TELAS DETALHADAS DO PAINEL
const telasModulos = {
  
  // 1. DASHBOARD
  "Dashboard": `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Dashboard Operacional</h1>
          <p class="text-slate-500 text-xs mt-0.5">Indicadores chave do abrigo no mês atual</p>
        </div>
        <span class="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full self-start sm:self-auto">Mês de Setembro</span>
      </div>

      <!-- CARDS DE METRICAS PRINCIPAIS -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-2">
            <span class="text-xs font-bold uppercase tracking-wider">Animais Abrigados</span>
            <span class="text-lg">🐶</span>
          </div>
          <p class="text-3xl font-bold text-slate-900">28</p>
          <span class="text-[11px] font-semibold text-emerald-600">85% da capacidade total</span>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-2">
            <span class="text-xs font-bold uppercase tracking-wider">Adoções Concluídas</span>
            <span class="text-lg">🏡</span>
          </div>
          <p class="text-3xl font-bold text-slate-900">14</p>
          <span class="text-[11px] font-semibold text-emerald-600">+12% em relação ao mês anterior</span>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-2">
            <span class="text-xs font-bold uppercase tracking-wider">Candidaturas em Análise</span>
            <span class="text-lg">📋</span>
          </div>
          <p class="text-3xl font-bold text-amber-600">9</p>
          <span class="text-[11px] font-semibold text-slate-500">Aguardando entrevista/visita</span>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-500 mb-2">
            <span class="text-xs font-bold uppercase tracking-wider">Tratamentos Médicos</span>
            <span class="text-lg">🩺</span>
          </div>
          <p class="text-3xl font-bold text-slate-900">6</p>
          <span class="text-[11px] font-semibold text-amber-600">2 em isolamento veterinário</span>
        </div>
      </div>

      <!-- PAINEL DE AVISOS E ATIVIDADES -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
          <h3 class="font-bold text-slate-900 text-sm mb-3 flex items-center gap-2">
            <span>🚨</span> Alertas do Sistema
          </h3>
          <div class="space-y-2">
            <div class="bg-red-50 border border-red-200 text-red-800 text-xs p-3 rounded-lg flex justify-between items-center">
              <div>
                <p class="font-bold">Estoque Crítico</p>
                <p class="text-[11px] text-red-600">Vacina Raiva possui apenas 4 frascos restantes.</p>
              </div>
              <button onclick="moduloAtivo='Estoque & Insumos'; carregarDadosJSON();" class="text-[11px] bg-red-600 text-white px-2.5 py-1 rounded font-semibold hover:bg-red-700">Ver</button>
            </div>
            <div class="bg-amber-50 border border-amber-200 text-amber-800 text-xs p-3 rounded-lg flex justify-between items-center">
              <div>
                <p class="font-bold">Consulta Agendada</p>
                <p class="text-[11px] text-amber-700">Thor (Cachorro) possui retorno médico hoje às 14:00.</p>
              </div>
              <button onclick="moduloAtivo='Agenda Médica'; carregarDadosJSON();" class="text-[11px] bg-amber-600 text-white px-2.5 py-1 rounded font-semibold hover:bg-amber-700">Agenda</button>
            </div>
          </div>
        </div>

        <div class="border border-slate-200 rounded-xl p-4">
          <h3 class="font-bold text-slate-900 text-sm mb-3 flex items-center gap-2">
            <span>📜</span> Últimas Atividades Registradas
          </h3>
          <ul class="text-xs space-y-3 text-slate-600">
            <li class="flex justify-between items-center border-b border-slate-100 pb-2">
              <span><strong>Dra. Camila</strong> registrou atendimento para Mel</span>
              <span class="text-slate-400 text-[10px]">Há 40 min</span>
            </li>
            <li class="flex justify-between items-center border-b border-slate-100 pb-2">
              <span><strong>Maria Silva</strong> enviou candidatura para adotar Luna</span>
              <span class="text-slate-400 text-[10px]">Há 2 horas</span>
            </li>
            <li class="flex justify-between items-center pb-1">
              <span><strong>Carlos</strong> cadastrou doação de 20kg de ração</span>
              <span class="text-slate-400 text-[10px]">Há 4 horas</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  `,

  // 2. ANIMAIS
  "Animais": `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Gestão do Plantel de Animais</h1>
          <p class="text-slate-500 text-xs">Controle individual de registro, abrigo e adoção</p>
        </div>
        <button onclick="alert('Formulário de cadastro de novo animal')" class="bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors flex items-center gap-2 self-start sm:self-auto shadow-sm">
          <span>+</span> Cadastrar Novo Pet
        </button>
      </div>

      <!-- BARRA DE PESQUISA E FILTROS -->
      <div class="flex flex-wrap gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <input type="text" placeholder="Buscar por nome ou microchip..." class="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs flex-1 focus:ring-2 focus:ring-primary-500 focus:outline-none">
        <select class="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs focus:ring-2 focus:ring-primary-500 focus:outline-none">
          <option>Todos os Status</option>
          <option>Disponível</option>
          <option>Em Tratamento</option>
          <option>Adotado</option>
        </select>
      </div>

      <!-- TABELA DETALHADA -->
      <div class="border rounded-xl overflow-hidden border-slate-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
          <table class="w-full text-xs text-left text-slate-600">
            <thead class="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-500 border-b border-slate-200">
              <tr>
                <th class="p-3">Código</th>
                <th class="p-3">Animal</th>
                <th class="p-3">Espécie / Raça</th>
                <th class="p-3">Idade / Porte</th>
                <th class="p-3">Localização</th>
                <th class="p-3">Status</th>
                <th class="p-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
              <tr class="hover:bg-slate-50/80 transition-colors">
                <td class="p-3 font-mono font-bold text-slate-400">#PET-001</td>
                <td class="p-3 font-bold text-slate-900 flex items-center gap-2">
                  <img src="https://images.unsplash.com/photo-1552053831-71594a27632d?w=100" class="w-8 h-8 rounded-full object-cover">
                  Thor
                </td>
                <td class="p-3">Cachorro (SRD)</td>
                <td class="p-3">2 anos • Grande</td>
                <td class="p-3">Canil B-03</td>
                <td class="p-3"><span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Disponível</span></td>
                <td class="p-3 text-right">
                  <button onclick="alert('Visualizar ficha técnica do Thor')" class="text-primary-600 hover:text-primary-800 font-semibold text-xs">Ficha</button>
                </td>
              </tr>
              <tr class="hover:bg-slate-50/80 transition-colors">
                <td class="p-3 font-mono font-bold text-slate-400">#PET-002</td>
                <td class="p-3 font-bold text-slate-900 flex items-center gap-2">
                  <img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=100" class="w-8 h-8 rounded-full object-cover">
                  Luna
                </td>
                <td class="p-3">Gato (Siamês)</td>
                <td class="p-3">6 meses • Pequeno</td>
                <td class="p-3">Gatil A-01</td>
                <td class="p-3"><span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Disponível</span></td>
                <td class="p-3 text-right">
                  <button onclick="alert('Visualizar ficha técnica da Luna')" class="text-primary-600 hover:text-primary-800 font-semibold text-xs">Ficha</button>
                </td>
              </tr>
              <tr class="hover:bg-slate-50/80 transition-colors">
                <td class="p-3 font-mono font-bold text-slate-400">#PET-003</td>
                <td class="p-3 font-bold text-slate-900 flex items-center gap-2">
                  <img src="https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=100" class="w-8 h-8 rounded-full object-cover">
                  Mel
                </td>
                <td class="p-3">Cachorro (Beagle)</td>
                <td class="p-3">1 ano • Médio</td>
                <td class="p-3">Enfermaria 02</td>
                <td class="p-3"><span class="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Em Tratamento</span></td>
                <td class="p-3 text-right">
                  <button onclick="alert('Visualizar ficha técnica da Mel')" class="text-primary-600 hover:text-primary-800 font-semibold text-xs">Ficha</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,

  // 3. ESTOQUE & INSUMOS
  "Estoque & Insumos": `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Estoque & Almoxarifado</h1>
          <p class="text-slate-500 text-xs">Controle de entrada e saída de alimentos e medicamentos</p>
        </div>
        <button onclick="alert('Entrada de material registrada')" class="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors shadow-sm">
          + Registrar Entrada
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="border border-slate-200 rounded-xl p-4 bg-white">
          <span class="text-[11px] font-bold text-slate-400 uppercase">Ração para Cães</span>
          <p class="text-2xl font-bold text-slate-900 mt-1">280 Kg</p>
          <p class="text-[11px] text-emerald-600 font-medium mt-1">Suficiente para 18 dias</p>
        </div>
        <div class="border border-slate-200 rounded-xl p-4 bg-white">
          <span class="text-[11px] font-bold text-slate-400 uppercase">Ração para Gatos</span>
          <p class="text-2xl font-bold text-slate-900 mt-1">95 Kg</p>
          <p class="text-[11px] text-emerald-600 font-medium mt-1">Suficiente para 24 dias</p>
        </div>
        <div class="border border-red-200 bg-red-50/50 rounded-xl p-4">
          <span class="text-[11px] font-bold text-red-600 uppercase">Itens em Nível Crítico</span>
          <p class="text-2xl font-bold text-red-700 mt-1">3 Itens</p>
          <p class="text-[11px] text-red-600 font-medium mt-1">Necessita reposição imediata</p>
        </div>
      </div>

      <div class="border rounded-xl overflow-hidden border-slate-200 bg-white">
        <table class="w-full text-xs text-left text-slate-600">
          <thead class="bg-slate-50 text-[11px] uppercase text-slate-500 border-b border-slate-200">
            <tr>
              <th class="p-3">Item / Insumo</th>
              <th class="p-3">Categoria</th>
              <th class="p-3">Quantidade</th>
              <th class="p-3">Validade</th>
              <th class="p-3">Status</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-200">
            <tr>
              <td class="p-3 font-bold text-slate-800">Ração Golden Adultos 15kg</td>
              <td class="p-3">Alimentação</td>
              <td class="p-3">14 Sacos</td>
              <td class="p-3">10/12/2026</td>
              <td class="p-3"><span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Normal</span></td>
            </tr>
            <tr>
              <td class="p-3 font-bold text-slate-800">Vacina Antirrábica 10ml</td>
              <td class="p-3">Medicamentos</td>
              <td class="p-3 font-bold text-red-600">4 Frascos</td>
              <td class="p-3">15/10/2026</td>
              <td class="p-3"><span class="bg-red-100 text-red-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Estoque Crítico</span></td>
            </tr>
            <tr>
              <td class="p-3 font-bold text-slate-800">Anti-inflamatório Meloxicam</td>
              <td class="p-3">Medicamentos</td>
              <td class="p-3">12 Caixas</td>
              <td class="p-3">05/08/2027</td>
              <td class="p-3"><span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Normal</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,

  // 4. AGENDA MÉDICA
  "Agenda Médica": `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Agenda Médica & Procedimentos</h1>
          <p class="text-slate-500 text-xs">Agendamentos de consultas, cirurgias e vacinações</p>
        </div>
        <button onclick="alert('Novo agendamento criado')" class="bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors">
          + Agendar Atendimento
        </button>
      </div>

      <div class="space-y-3">
        <div class="border border-slate-200 rounded-xl p-4 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm border-l-4 border-l-primary-500">
          <div class="flex items-start gap-4">
            <div class="bg-primary-50 text-primary-700 p-3 rounded-lg text-center min-w-[70px]">
              <span class="block text-xs uppercase font-bold">Hoje</span>
              <span class="block text-xl font-bold">14:00</span>
            </div>
            <div>
              <span class="text-[10px] font-bold uppercase bg-slate-100 px-2 py-0.5 rounded text-slate-600">Retorno Clínico</span>
              <h3 class="font-bold text-slate-900 text-base mt-1">Thor (Cachorro)</h3>
              <p class="text-xs text-slate-500">Motivo: Avaliação pós-operatória de castração • Resp: Dra. Camila</p>
            </div>
          </div>
          <div class="flex gap-2 self-end md:self-auto">
            <button onclick="alert('Atendimento concluído')" class="bg-primary-600 text-white text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-primary-700">Concluir</button>
            <button onclick="alert('Atendimento reagendado')" class="bg-slate-100 text-slate-700 text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-slate-200">Adiar</button>
          </div>
        </div>

        <div class="border border-slate-200 rounded-xl p-4 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm border-l-4 border-l-blue-500">
          <div class="flex items-start gap-4">
            <div class="bg-blue-50 text-blue-700 p-3 rounded-lg text-center min-w-[70px]">
              <span class="block text-xs uppercase font-bold">Amanhã</span>
              <span class="block text-xl font-bold">09:30</span>
            </div>
            <div>
              <span class="text-[10px] font-bold uppercase bg-slate-100 px-2 py-0.5 rounded text-slate-600">Vacinação V10</span>
              <h3 class="font-bold text-slate-900 text-base mt-1">Luna (Gato)</h3>
              <p class="text-xs text-slate-500">Motivo: Segunda dose da vacina • Resp: Dr. Roberto</p>
            </div>
          </div>
          <div class="flex gap-2 self-end md:self-auto">
            <button onclick="alert('Atendimento confirmado')" class="bg-slate-100 text-slate-700 text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-slate-200">Confirmar</button>
          </div>
        </div>
      </div>
    </div>
  `,

  // 5. PRONTUÁRIO CLÍNICO
  "Prontuário Clínico": `
    <div class="space-y-6">
      <div class="border-b border-slate-100 pb-4">
        <h1 class="text-2xl font-bold text-slate-900">Prontuário Veterinário Eletrônico</h1>
        <p class="text-slate-500 text-xs mt-0.5">Histórico completo de saúde e tratamentos por animal</p>
      </div>

      <div class="bg-slate-50 p-4 border border-slate-200 rounded-xl space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div class="flex items-center gap-3">
            <div class="w-12 h-12 rounded-full bg-slate-300 overflow-hidden">
              <img src="https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=200" class="w-full h-full object-cover">
            </div>
            <div>
              <h2 class="text-lg font-bold text-slate-900">Mel (Cachorro)</h2>
              <p class="text-xs text-slate-500">Beagle • Fêmea • 1 ano • 11.2 Kg</p>
            </div>
          </div>
          <span class="bg-amber-100 text-amber-800 text-xs font-bold px-3 py-1 rounded-full self-start sm:self-auto">Em Tratamento</span>
        </div>

        <div class="border-t border-slate-200 pt-4 space-y-3">
          <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider">Histórico de Ocorrências:</h3>
          
          <div class="bg-white p-3 border border-slate-200 rounded-lg space-y-1">
            <div class="flex justify-between text-xs text-slate-500">
              <span class="font-bold text-slate-800">Dermatite Alérgica - Consulta Inicial</span>
              <span>12/09/2026</span>
            </div>
            <p class="text-xs text-slate-600">Prescrito pomada antisséptica a cada 12 horas e banho terapêutico semanal. Animal apresentou melhora significativa na coceira.</p>
            <p class="text-[11px] text-slate-400 mt-1">Veterinária Responsável: Dra. Camila Santos (CRMV 12345)</p>
          </div>
        </div>
      </div>
    </div>
  `,

  // 6. CANDIDATURAS
  "Candidaturas": `
    <div class="space-y-6">
      <div class="border-b border-slate-100 pb-4">
        <h1 class="text-2xl font-bold text-slate-900">Análise de Candidaturas de Adoção</h1>
        <p class="text-slate-500 text-xs">Avaliação de formulários enviados pelos interessados</p>
      </div>

      <div class="space-y-4">
        <div class="border border-slate-200 rounded-xl p-5 bg-white shadow-sm space-y-3">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div>
              <span class="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">Candidatura #AD-892</span>
              <h3 class="text-lg font-bold text-slate-900 mt-1">Maria Silva dos Santos</h3>
              <p class="text-xs text-slate-500">E-mail: maria.silva@email.com • Tel: (13) 99887-6655</p>
            </div>
            <span class="text-xs font-bold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 self-start sm:self-auto">Aguardando Entrevista</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
            <div>
              <p class="font-bold text-slate-700">Animal Solicitado:</p>
              <p class="text-slate-600">Luna (Gato - 6 meses)</p>
            </div>
            <div>
              <p class="font-bold text-slate-700">Tipo de Moradia:</p>
              <p class="text-slate-600">Apartamento (Com telas de proteção)</p>
            </div>
            <div class="md:col-span-2">
              <p class="font-bold text-slate-700">Descrição do Espaço e Rotina:</p>
              <p class="text-slate-600 italic">"Trabalho em home office, já possuo uma gatinha castrada e vacinada de 3 anos. O apartamento é totalmente protegido com redes nas janelas."</p>
            </div>
          </div>

          <div class="flex justify-end gap-2 pt-1">
            <button onclick="alert('Candidatura Aprovada!')" class="bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors">Aprovar Candidatura</button>
            <button onclick="alert('Candidatura Rejeitada')" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-4 py-2 rounded-lg transition-colors">Recusar</button>
          </div>
        </div>
      </div>
    </div>
  `,

  // 7. DOAÇÕES
  "Doações": `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Relatório de Doações</h1>
          <p class="text-slate-500 text-xs">Controle financeiro e doações físicas de colaboradores</p>
        </div>
        <button onclick="alert('Registrar doação')" class="bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold px-4 py-2 rounded-lg">
          + Nova Doação
        </button>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div class="border border-slate-200 p-4 rounded-xl bg-white">
          <span class="text-xs font-bold text-slate-400 uppercase">Arrecadação PIX/Transferência (Mês)</span>
          <p class="text-3xl font-bold text-primary-700 mt-1">R$ 5.420,00</p>
          <span class="text-[11px] text-emerald-600 font-medium">Meta mensal de R$ 6.000 atingida em 90%</span>
        </div>
        <div class="border border-slate-200 p-4 rounded-xl bg-white">
          <span class="text-xs font-bold text-slate-400 uppercase">Doações Físicas Registradas</span>
          <p class="text-3xl font-bold text-slate-800 mt-1">22 Registros</p>
          <span class="text-[11px] text-slate-500">Ração, medicamentos e cobertas</span>
        </div>
      </div>

      <div class="border rounded-xl overflow-hidden border-slate-200 bg-white">
        <table class="w-full text-xs text-left text-slate-600">
          <thead class="bg-slate-50 text-[11px] uppercase text-slate-500 border-b border-slate-200">
            <tr>
              <th class="p-3">Doador</th>
              <th class="p-3">Tipo</th>
              <th class="p-3">Descrição / Valor</th>
              <th class="p-3">Data</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-200">
            <tr>
              <td class="p-3 font-bold text-slate-800">Carlos Eduardo</td>
              <td class="p-3"><span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Financeiro</span></td>
              <td class="p-3 font-bold text-slate-900">R$ 200,00 (PIX)</td>
              <td class="p-3">Hoje, 10:15</td>
            </tr>
            <tr>
              <td class="p-3 font-bold text-slate-800">Empresa PetCare Ltda</td>
              <td class="p-3"><span class="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Insumos</span></td>
              <td class="p-3">3 Sacos de Ração 15kg</td>
              <td class="p-3">Ontem, 16:30</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,

  // 8. VOLUNTÁRIOS
  "Voluntários": `
    <div class="space-y-6">
      <div class="border-b border-slate-100 pb-4">
        <h1 class="text-2xl font-bold text-slate-900">Corpo de Voluntários</h1>
        <p class="text-slate-500 text-xs">Gestão de colaboradores inscritos na ONG</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="border border-slate-200 p-4 rounded-xl bg-white flex justify-between items-center">
          <div>
            <h3 class="font-bold text-slate-900 text-sm">Ana Clara Pires</h3>
            <p class="text-xs text-slate-500">Função: Recreação e Passeio</p>
            <p class="text-[11px] text-slate-400 mt-1">Disponibilidade: Finais de Semana</p>
          </div>
          <span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-1 rounded-full">Ativo</span>
        </div>

        <div class="border border-slate-200 p-4 rounded-xl bg-white flex justify-between items-center">
          <div>
            <h3 class="font-bold text-slate-900 text-sm">Lucas Mendes</h3>
            <p class="text-xs text-slate-500">Função: Higienização e Apoio</p>
            <p class="text-[11px] text-slate-400 mt-1">Disponibilidade: Terças e Quintas</p>
          </div>
          <span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-1 rounded-full">Ativo</span>
        </div>
      </div>
    </div>
  `,

  // 9. ESCALAS DE VOLUNTÁRIOS
  "Escalas de Voluntários": `
    <div class="space-y-6">
      <div class="border-b border-slate-100 pb-4">
        <h1 class="text-2xl font-bold text-slate-900">Escala Semanal de Voluntários</h1>
        <p class="text-slate-500 text-xs">Organização de turnos e tarefas do abrigo</p>
      </div>

      <div class="space-y-3">
        <div class="border border-slate-200 rounded-xl p-4 bg-white space-y-2">
          <div class="flex justify-between items-center border-b border-slate-100 pb-2">
            <h3 class="font-bold text-slate-900 text-sm">Sábado - Turno Manhã (08:00 às 12:00)</h3>
            <span class="text-xs font-bold text-primary-700 bg-primary-50 px-2 py-0.5 rounded">2 Escalados</span>
          </div>
          <ul class="text-xs text-slate-600 space-y-1">
            <li class="flex justify-between"><span>• <strong>Ana Clara Pires</strong> (Passeio dos Cães do Canil B)</span> <span class="text-emerald-600 font-bold">Confirmado</span></li>
            <li class="flex justify-between"><span>• <strong>Lucas Mendes</strong> (Limpeza do Gatil Principal)</span> <span class="text-emerald-600 font-bold">Confirmado</span></li>
          </ul>
        </div>
      </div>
    </div>
  `,

  // 10. RELATÓRIOS
  "Relatórios": `
    <div class="space-y-6">
      <div class="border-b border-slate-100 pb-4">
        <h1 class="text-2xl font-bold text-slate-900">Relatórios Executivos & Exportação</h1>
        <p class="text-slate-500 text-xs">Gere documentos oficiais e dados consolidados em PDF e CSV</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="border border-slate-200 rounded-xl p-4 bg-white space-y-2">
          <h3 class="font-bold text-slate-900 text-sm">Relatório Mensal de Adoções</h3>
          <p class="text-xs text-slate-500">Contém estatísticas de animais adotados, perfil dos adotantes e tempo médio no abrigo.</p>
          <button onclick="alert('Download do Relatório em PDF iniciado!')" class="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold py-2 rounded-lg transition-colors mt-2">Exportar em PDF</button>
        </div>

        <div class="border border-slate-200 rounded-xl p-4 bg-white space-y-2">
          <h3 class="font-bold text-slate-900 text-sm">Balanço de Estoque & Medicamentos</h3>
          <p class="text-xs text-slate-500">Relação completa de insumos consumidos, doações recebidas e perdas no período.</p>
          <button onclick="alert('Download da Planilha em CSV iniciado!')" class="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold py-2 rounded-lg transition-colors mt-2">Exportar em CSV</button>
        </div>
      </div>
    </div>
  `,

  // 11. USUÁRIOS & ACESSOS
  "Usuários & Acessos": `
    <div class="space-y-6">
      <div class="flex justify-between items-center border-b border-slate-100 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Gestão de Usuários do Sistema</h1>
          <p class="text-slate-500 text-xs">Controle de perfis, senhas e permissões de acesso</p>
        </div>
        <button onclick="alert('Novo usuário cadastrado')" class="bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold px-4 py-2 rounded-lg">+ Novo Usuário</button>
      </div>

      <div class="border rounded-xl overflow-hidden border-slate-200 bg-white">
        <table class="w-full text-xs text-left text-slate-600">
          <thead class="bg-slate-50 text-[11px] uppercase text-slate-500 border-b border-slate-200">
            <tr>
              <th class="p-3">Usuário / E-mail</th>
              <th class="p-3">Perfil de Acesso</th>
              <th class="p-3">Último Acesso</th>
              <th class="p-3">Status</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-200">
            <tr>
              <td class="p-3 font-bold text-slate-800">admin@codepaws.org</td>
              <td class="p-3"><span class="bg-purple-100 text-purple-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Administrador</span></td>
              <td class="p-3">Hoje, 11:20</td>
              <td class="p-3"><span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Ativo</span></td>
            </tr>
            <tr>
              <td class="p-3 font-bold text-slate-800">camila.vet@codepaws.org</td>
              <td class="p-3"><span class="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Veterinário</span></td>
              <td class="p-3">Hoje, 09:45</td>
              <td class="p-3"><span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Ativo</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
};

// CARREGAMENTO DOS DADOS JSON
async function carregarDadosJSON() {
  try {
    const resposta = await fetch('dados.json');
    const dados = await resposta.json();
    
    pets = dados.pets;
    permissoesPorPerfil = dados.permissoesPorPerfil;

    if (document.getElementById("listaPets")) {
      inicializarCatalogo();
    }
    
    if (document.getElementById("formAdocao")) {
      inicializarFormularioAdocao();
    }

    if (document.getElementById("menuModulos")) {
      inicializarPainelAdmin();
    }

    if (document.getElementById("formLogin")) {
      inicializarLogin();
    }

  } catch (erro) {
    console.error("Erro ao carregar os dados:", erro);
  }
}

// 1. CATÁLOGO
function inicializarCatalogo() {
  const listaPetsContainer = document.getElementById("listaPets");
  const filtroEspecie = document.getElementById("filtroEspecie");
  const filtroPorte = document.getElementById("filtroPorte");

  function renderizarPets() {
    const especieSelecionada = filtroEspecie.value;
    const porteSelecionado = filtroPorte.value;

    listaPetsContainer.innerHTML = "";

    const petsFiltrados = pets.filter(pet => {
      const bateuEspecie = especieSelecionada === "todas" || pet.especie === especieSelecionada;
      const bateuPorte = porteSelecionado === "todos" || pet.porte === porteSelecionado;
      return bateuEspecie && bateuPorte;
    });

    petsFiltrados.forEach(pet => {
      const cardHtml = `
        <article class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col">
          <div class="h-48 overflow-hidden bg-slate-100">
            <img src="${pet.foto}" alt="Foto de ${pet.nome}" class="w-full h-full object-cover">
          </div>
          <div class="p-5 flex-1 flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between mb-2">
                <h3 class="text-lg font-bold text-slate-900">${pet.nome}</h3>
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                  Disponível
                </span>
              </div>
              <p class="text-xs text-slate-500 font-medium capitalize mb-4">
                ${pet.especie} • Porte ${pet.porte} • ${pet.idade}
              </p>
            </div>
            <button onclick="irParaFormularioComPet(${pet.id})" class="w-full text-center bg-slate-100 hover:bg-primary-600 hover:text-white text-slate-700 font-medium text-sm py-2 rounded-lg transition-colors">
              Quero Adotar
            </button>
          </div>
        </article>
      `;
      listaPetsContainer.innerHTML += cardHtml;
    });
  }

  filtroEspecie.addEventListener("change", renderizarPets);
  filtroPorte.addEventListener("change", renderizarPets);
  renderizarPets();
}

function irParaFormularioComPet(petId) {
  window.location.href = `candidatura.html?petId=${petId}`;
}

// 2. CANDIDATURA
function inicializarFormularioAdocao() {
  const selectPetInteresse = document.getElementById("petInteresse");
  const formAdocao = document.getElementById("formAdocao");

  selectPetInteresse.innerHTML = `<option value="">Selecione um pet...</option>`;
  pets.forEach(pet => {
    const option = document.createElement("option");
    option.value = pet.id;
    option.textContent = `${pet.nome} (${pet.especie} - Porte ${pet.porte})`;
    selectPetInteresse.appendChild(option);
  });

  const urlParams = new URLSearchParams(window.location.search);
  const petIdUrl = urlParams.get('petId');
  if (petIdUrl) {
    selectPetInteresse.value = petIdUrl;
  }

  formAdocao.addEventListener("submit", (e) => {
    e.preventDefault();
    const nome = document.getElementById("nomeInscrito").value;
    const petId = selectPetInteresse.value;
    const petEncontrado = pets.find(p => p.id == petId);

    alert(`Obrigado, ${nome}! Sua intenção de adoção para o pet "${petEncontrado ? petEncontrado.nome : 'selecionado'}" foi enviada com sucesso!`);
    window.location.href = "index.html";
  });
}

// 3. PAINEL ADMIN
function inicializarPainelAdmin() {
  const selectPerfil = document.getElementById("selectPerfil");
  const menuModulos = document.getElementById("menuModulos");
  const conteudoModulo = document.getElementById("conteudoModulo");

  const perfilSalvo = localStorage.getItem("codepaws_perfil_ativo");
  if (perfilSalvo && permissoesPorPerfil[perfilSalvo]) {
    selectPerfil.value = perfilSalvo;
  }

  function renderizarMenuEConteudo() {
    const perfil = selectPerfil.value;
    const modulosLiberados = permissoesPorPerfil[perfil] || [];

    if (!modulosLiberados.includes(moduloAtivo)) {
      moduloAtivo = modulosLiberados[0] || "Dashboard";
    }

    menuModulos.innerHTML = "";
    modulosLiberados.forEach(modulo => {
      const btn = document.createElement("button");
      const isSelected = modulo === moduloAtivo;
      
      btn.className = `w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center justify-between ${
        isSelected 
          ? "bg-primary-50 text-primary-800 font-bold border border-primary-200 shadow-sm" 
          : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
      }`;
      
      btn.textContent = modulo;
      btn.onclick = () => {
        moduloAtivo = modulo;
        renderizarMenuEConteudo();
      };

      menuModulos.appendChild(btn);
    });

    conteudoModulo.innerHTML = telasModulos[moduloAtivo] || `<p class="text-slate-500">Módulo em desenvolvimento.</p>`;
  }

  selectPerfil.addEventListener("change", () => {
    localStorage.setItem("codepaws_perfil_ativo", selectPerfil.value);
    renderizarMenuEConteudo();
  });

  renderizarMenuEConteudo();
}

// 4. LOGIN
function inicializarLogin() {
  const formLogin = document.getElementById("formLogin");
  formLogin.addEventListener("submit", (e) => {
    e.preventDefault();
    window.location.href = "admin.html";
  });
}

// Inicializar
carregarDadosJSON();